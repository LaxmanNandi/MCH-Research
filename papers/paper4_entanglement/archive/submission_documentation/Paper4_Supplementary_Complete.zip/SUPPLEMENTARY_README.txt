================================================================================
PAPER 4: SUPPLEMENTARY MATERIALS PACKAGE
================================================================================

Title: Engagement as Entanglement: Variance Signatures of Bidirectional
       Context Coupling in Large Language Models

Author: Dr. Laxman M M, MBBS
Date: February 22, 2026

================================================================================
CONTENTS OF THIS PACKAGE
================================================================================

1. Paper4_Supplementary.tex
   - LaTeX source file for supplementary materials
   - Includes all 4 supplementary figures and 2 supplementary tables
   - Can be compiled with pdflatex or uploaded to Overleaf

2. Paper4_Supplementary.pdf
   - Compiled PDF (890 KB)
   - Ready for review and submission
   - Contains:
     * Figure S1: Information-Theoretic Verification (r=0.76, p=2.37×10⁻⁶⁸)
     * Figure S2: Trial-Level Convergence Analysis (11/12 non-significant)
     * Figure S3: Model-Level ΔRCI Comparison
     * Figure S4: Lost in Conversation Experimental Validation
     * Table S1: Complete Model-Position Data (360 observations)
     * Table S2: ESI Classification and Recovery Rates (12 models)
     * Table S3: Var_Ratio Progression Statistics
     * Supplementary Methods and Discussion

================================================================================
FIGURE FILES (Required for Compilation)
================================================================================

The .tex file references these figure files (located in ../figures/):

1. figure6_gaussian_verification.png (Figure S1)
2. figure8_trial_convergence.png (Figure S2)
3. figure9_model_comparison.png (Figure S3)
4. lost_in_conversation_tests.png (Figure S4)

All figures have been regenerated with verified statistics (Feb 21-22, 2026).

================================================================================
VERIFICATION STATUS
================================================================================

✓ All statistics verified against raw data
✓ All p-values corrected (p = 2.37×10⁻⁶⁸)
✓ All model counts correct (12 models: 4 Phil, 8 Med)
✓ All domain assignments correct per Paper 3
✓ All table values verified from source data
✓ All figure captions accurate

See: FINAL_SUPPLEMENTARY_VERIFICATION.md for complete verification checklist

================================================================================
COMPILATION INSTRUCTIONS
================================================================================

If you need to recompile the PDF:

Method 1: pdflatex (command line)
  cd supplementary/
  pdflatex Paper4_Supplementary.tex
  (Run twice for table of contents)

Method 2: Overleaf
  1. Upload Paper4_Supplementary.tex
  2. Upload all 4 figure PNG files
  3. Compile with pdfLaTeX

Required Packages:
  - amsmath, amssymb, mathptmx
  - graphicx, booktabs, array
  - hyperref, xcolor, float
  - caption, subcaption, longtable

================================================================================
SUBMISSION NOTES
================================================================================

For Preprints.org submission:
1. Upload Paper4_Supplementary.pdf as "Supplementary File"
2. Optionally upload Paper4_Supplementary.tex as LaTeX source
3. Figure files are embedded in the PDF (no separate upload needed)

Total package size: ~900 KB

================================================================================
DATA AVAILABILITY
================================================================================

All raw data referenced in supplementary materials available at:
https://github.com/LaxmanNandi/MCH-Research/

Specific data files:
- entanglement_position_data.csv (360 observations)
- lost_in_conversation_progression.csv (Table S2/S3)
- figure1_entanglement_scatter_360points.csv (Figure S1)

================================================================================
CONTACT
================================================================================

Dr. Laxman M M, MBBS
Government Duty Medical Officer
Primary Health Centre Manchi, Bantwal Taluk
Dakshina Kannada, Karnataka, India

DNB General Medicine Resident (2026)
KC General Hospital, Bangalore

GitHub: https://github.com/LaxmanNandi/MCH-Research

================================================================================
